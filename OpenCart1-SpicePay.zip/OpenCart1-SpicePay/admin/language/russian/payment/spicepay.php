<?php
// Heading
$_['heading_title']      = 'SpicePay';

// Text
$_['text_payment']       = 'Оплата';
$_['text_success']       = 'Настройки модуля обновлены!';
$_['text_yes']           = 'Да';
$_['text_no']            = 'Нет';

// Entry
$_['entry_login']        = 'Spicepay Site ID:';
$_['entry_password1']    = 'Spicepay Callback Secret:';

$_['entry_order_status'] = 'Статус заказа после оплаты:';
$_['entry_geo_zone']     = 'Географическая зона:';
$_['entry_status']       = 'Статус:';
$_['entry_sort_order']   = 'Порядок сортировки:';

$_['error_permission']   = 'У Вас нет прав для управления этим модулем!';
$_['error_login']        = 'Требуется ввести Spicepay Site ID!';
$_['error_password1']    = 'Требуется ввести Spicepay Callback Secret!';
?>